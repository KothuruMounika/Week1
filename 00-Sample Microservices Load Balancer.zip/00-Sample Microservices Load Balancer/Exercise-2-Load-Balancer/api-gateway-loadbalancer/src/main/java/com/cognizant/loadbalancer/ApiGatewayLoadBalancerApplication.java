package com.cognizant.loadbalancer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiGatewayLoadBalancerApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayLoadBalancerApplication.class, args);
    }
}