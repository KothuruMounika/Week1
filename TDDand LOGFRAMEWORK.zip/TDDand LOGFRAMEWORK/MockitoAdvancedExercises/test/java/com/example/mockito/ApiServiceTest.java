package com.example.mockito;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ApiServiceTest {

    @Test
    void testServiceWithMockRestClient() {

        RestClient mockClient =
                mock(RestClient.class);

        when(mockClient.getResponse())
                .thenReturn("Mock Response");

        ApiService apiService =
                new ApiService(mockClient);

        String result =
                apiService.fetchData();

        assertEquals(
                "Fetched Mock Response",
                result);
    }
}