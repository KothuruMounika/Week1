package com.example.mockito;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;

public class ArgumentMatchingTest {

    @Test
    void testArgumentMatching() {

        ExternalApi mockApi = mock(ExternalApi.class);

        mockApi.getUserData("Mounika");

        verify(mockApi).getUserData(anyString());
    }
}