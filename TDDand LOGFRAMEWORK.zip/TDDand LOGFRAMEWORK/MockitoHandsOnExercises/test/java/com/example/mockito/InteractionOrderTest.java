package com.example.mockito;

import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

public class InteractionOrderTest {

    @Test
    void testInteractionOrder() {

        ExternalApi mockApi =
                mock(ExternalApi.class);

        mockApi.getData();
        mockApi.getUserData("Mounika");

        InOrder inOrder =
                inOrder(mockApi);

        inOrder.verify(mockApi)
               .getData();

        inOrder.verify(mockApi)
               .getUserData("Mounika");
    }
}