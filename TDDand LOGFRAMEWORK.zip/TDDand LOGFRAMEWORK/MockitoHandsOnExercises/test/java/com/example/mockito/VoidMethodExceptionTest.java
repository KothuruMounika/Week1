package com.example.mockito;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;

public class VoidMethodExceptionTest {

    @Test
    void testVoidMethodException() {

        NotificationService service =
                mock(NotificationService.class);

        doThrow(
                new RuntimeException(
                        "Notification Failed"))
                .when(service)
                .sendNotification();

        assertThrows(
                RuntimeException.class,
                () -> service.sendNotification());
    }
}