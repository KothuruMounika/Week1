package com.example.mockito;

public class NotificationService {

    public void sendNotification() {

    }
}