package com.example.mockito;

public interface ExternalApi {

    String getData();

    String getUserData(String username);
}