package com.example.junit;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class OrderedTests {

    @Test
    @Order(1)
    void loginTest() {

        System.out.println("Login Test Executed");
    }

    @Test
    @Order(2)
    void searchTest() {

        System.out.println("Search Test Executed");
    }

    @Test
    @Order(3)
    void logoutTest() {

        System.out.println("Logout Test Executed");
    }
}