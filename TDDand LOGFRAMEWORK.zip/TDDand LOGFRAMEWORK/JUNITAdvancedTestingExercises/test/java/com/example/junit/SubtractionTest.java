package com.example.junit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class SubtractionTest {

    @Test
    void testSubtraction() {

        int result = 10 - 5;

        assertEquals(5, result);
    }
}