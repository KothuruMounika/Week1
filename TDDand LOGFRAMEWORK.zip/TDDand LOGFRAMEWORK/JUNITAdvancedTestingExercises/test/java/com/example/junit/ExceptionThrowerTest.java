package com.example.junit;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

public class ExceptionThrowerTest {

    @Test
    void testException() {

        ExceptionThrower exceptionThrower =
                new ExceptionThrower();

        assertThrows(
                ArithmeticException.class,
                () -> exceptionThrower.throwException()
        );
    }
}