package com.example.junit;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class AdditionTest {

    @Test
    void testAddition() {

        int result = 5 + 5;

        assertEquals(10, result);
    }
}