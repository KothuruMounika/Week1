package com.example.junit;

public class PerformanceTester {

    public void performTask() throws InterruptedException {
        Thread.sleep(1000);
    }
}