package com.example.junit;

import org.junit.Test;

public class SampleTest {

    @Test
    public void testJUnitSetup() {
        System.out.println("JUnit setup completed successfully.");
    }
}