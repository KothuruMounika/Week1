package com.example.junit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CalculatorAAATest {

    private Calculator calculator;

    @Before
    public void setUp() {
        System.out.println("Setting up Calculator object...");
        calculator = new Calculator();
    }

    @After
    public void tearDown() {
        System.out.println("Cleaning up resources...");
        calculator = null;
    }

    @Test
    public void testAdditionUsingAAA() {

        // Arrange
        int firstNumber = 25;
        int secondNumber = 15;

        // Act
        int result = calculator.add(firstNumber, secondNumber);

        // Assert
        assertEquals(40, result);
    }
}