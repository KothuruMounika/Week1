package com.example.springtesting;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import com.example.springtesting.entity.User;
import com.example.springtesting.repository.UserRepository;
import com.example.springtesting.service.UserService;

public class UserServiceTest {

    @Test
    void testGetUserById() {

        UserRepository repository =
                mock(UserRepository.class);

        User user = new User();
        user.setId(1L);
        user.setName("Mounika");

        when(repository.findById(1L))
                .thenReturn(Optional.of(user));

        UserService service =
                new UserService(repository);

        User result =
                service.getUserById(1L);

        assertEquals("Mounika",
                result.getName());
    }
}