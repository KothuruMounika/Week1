package com.example.springtesting;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class UserRepositoryTest {

    @Test
    void testFindByName() {

        assertTrue(true);
    }
}