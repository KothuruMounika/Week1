package com.example.springtesting;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class CreateUserControllerTest {

    @Test
    void testCreateUser() {

        assertTrue(true);
    }
}