package com.example.springtesting;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import com.example.springtesting.service.CalculatorService;

public class ParameterizedCalculatorTest {

    CalculatorService service =
            new CalculatorService();

    @ParameterizedTest
    @CsvSource({
        "2,3,5",
        "5,5,10",
        "10,20,30"
    })
    void testAdd(
            int a,
            int b,
            int expected) {

        assertEquals(
                expected,
                service.add(a, b));
    }
}