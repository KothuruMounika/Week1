package com.example.springtesting;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import com.example.springtesting.service.CalculatorService;

public class CalculatorServiceTest {

    @Test
    void testAdd() {

        CalculatorService service =
                new CalculatorService();

        assertEquals(10,
                service.add(4, 6));
    }
}