package com.example.springtesting;

import static org.junit.jupiter.api.Assertions.*;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.Test;

public class GlobalExceptionHandlerTest {

    @Test
    void testExceptionHandling() {

        assertThrows(
                NoSuchElementException.class,
                () -> {
                    throw new NoSuchElementException();
                });
    }
}