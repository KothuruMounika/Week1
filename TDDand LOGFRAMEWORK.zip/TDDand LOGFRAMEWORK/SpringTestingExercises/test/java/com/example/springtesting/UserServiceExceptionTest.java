package com.example.springtesting;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import com.example.springtesting.repository.UserRepository;
import com.example.springtesting.service.UserService;

public class UserServiceExceptionTest {

    @Test
    void testUserNotFound() {

        UserRepository repository =
                mock(UserRepository.class);

        when(repository.findById(99L))
                .thenReturn(Optional.empty());

        UserService service =
                new UserService(repository);

        assertNull(
                service.getUserById(99L));
    }
}