package TDDand LOGFRAMEWORK.SpringTestingExercises.src.main.java.com.example.springtesting.exception;

public class GlobalExceptionHandler {
    
}
