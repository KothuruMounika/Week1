package TDDand LOGFRAMEWORK.SpringTestingExercises.src.main.java.com.example.springtesting.entity.repository;

public class UserRepository {
    
}
