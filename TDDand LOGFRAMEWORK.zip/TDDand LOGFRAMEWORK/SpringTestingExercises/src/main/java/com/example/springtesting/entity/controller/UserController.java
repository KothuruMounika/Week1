package TDDand LOGFRAMEWORK.SpringTestingExercises.src.main.java.com.example.springtesting.entity.controller;

public class UserController {
    
}
