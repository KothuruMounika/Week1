
package com.library.service;

import com.library.repository.BookRepository;
//import org.springframework.stereotype.Service;

//@Service

public class BookService {

    private BookRepository bookRepository;
    private String libraryName;

    // Constructor Injection
    public BookService(String libraryName) {
        this.libraryName = libraryName;
    }

    // Setter Injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void displayService() {

        System.out.println("Library Name : " + libraryName);
        System.out.println("Book Service is working");

        if(bookRepository != null) {
            bookRepository.displayRepository();
        }
    }
}
