package com.library;

import com.library.repository.BookRepository;
import com.library.service.BookService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

    public static void main(String[] args) {

        ApplicationContext c =
                new ClassPathXmlApplicationContext("applicationContext.xml");

        BookService s =
                (BookService) c.getBean("bookService");

        BookRepository r =
                (BookRepository) c.getBean("bookRepository");

        System.out.println("Exercise -1");
        s.displayService();
        r.displayRepository();

        System.out.println();

        System.out.println("Exercise -2");
        s.displayService();

        System.out.println();

        System.out.println("Exercise -3");
        s.displayService();
        System.out.println("LibraryManagement Maven Project Initialized Successfully");
        System.out.println("All Required Spring Dependencies Loaded Successfully");
        System.out.println("Project Build Configuration Verified");

        System.out.println();
        System.out.println("Exercise -5");



        s.displayService();

        System.out.println("Spring IoC Container Configured Successfully");

        System.out.println("\nExercise -6");


        s.displayService();

        System.out.println("Annotation Based Configuration Successful");

        System.out.println("\nExercise -7");

        BookService s7 =
                (BookService) c.getBean("bookService");

        s7.displayService();



        System.out.println("\nExercise -8");

        BookService s8 =
                (BookService) c.getBean("bookService");

        s8.displayService();
    }
}