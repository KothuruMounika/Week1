package com.example.ormlearn.repository;

import com.example.ormlearn.entity.Employee;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

    @Query("""
        SELECT e FROM Employee e
        LEFT JOIN FETCH e.department
        LEFT JOIN FETCH e.skillList
        WHERE e.permanent = true
    """)
    List<Employee> getAllPermanentEmployees();

    @Query("""
        SELECT AVG(e.salary)
        FROM Employee e
        WHERE e.department.id = :deptId
    """)
    Double getAverageSalary(@Param("deptId") int deptId);


    @Query(value = "SELECT * FROM employee", nativeQuery = true)
    List<Employee> getAllEmployeesNative();

    List<Employee> findByDepartmentId(int deptId);
}