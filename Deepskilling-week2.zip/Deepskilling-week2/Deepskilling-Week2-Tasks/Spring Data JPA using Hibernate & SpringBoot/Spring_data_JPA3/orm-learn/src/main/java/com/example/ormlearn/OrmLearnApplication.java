package com.example.ormlearn;

import com.example.ormlearn.entity.Attempt;
import com.example.ormlearn.entity.AttemptOption;
import com.example.ormlearn.entity.AttemptQuestion;
import com.example.ormlearn.service.AttemptService;
import com.example.ormlearn.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrmLearnApplication implements CommandLineRunner {

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private AttemptService attemptService;

    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        System.out.println("\n===== PERMANENT EMPLOYEES =====");

        employeeService.getAllPermanentEmployees()
                .forEach(e -> {
                    System.out.println("Employee: " + e.getName());
                    System.out.println("Department: " +
                            (e.getDepartment() != null ? e.getDepartment().getName() : "NULL"));

                    System.out.println("Skills: " + e.getSkillList());
                });



        System.out.println("\n===== AVG SALARY =====");

        Double avgSalary = employeeService.getAverageSalary(1);
        System.out.println("Department 1 Avg Salary: " + avgSalary);



        System.out.println("\n===== NATIVE QUERY =====");

        employeeService.getAllEmployeesNative()
                .forEach(e -> System.out.println(e.getName()));


      
        System.out.println("\n===== QUIZ ATTEMPT DETAILS =====");

        Attempt attempt = attemptService.getAttempt(1, 1);

        System.out.println("User: " + attempt.getUser().getUsername());
        System.out.println("Attempt ID: " + attempt.getId());
        System.out.println("Date: " + attempt.getAttemptedDate());

        for (AttemptQuestion aq : attempt.getAttemptQuestions()) {

            System.out.println("\nQ: " + aq.getQuestion().getText());

            for (AttemptOption ao : aq.getAttemptOptions()) {

                System.out.println(
                        ao.getOption().getText()
                                + " | Score: " + ao.getOption().getScore()
                                + " | Selected: " + ao.isSelected()
                );
            }
        }

        System.out.println("\n===== END =====");
    }
}