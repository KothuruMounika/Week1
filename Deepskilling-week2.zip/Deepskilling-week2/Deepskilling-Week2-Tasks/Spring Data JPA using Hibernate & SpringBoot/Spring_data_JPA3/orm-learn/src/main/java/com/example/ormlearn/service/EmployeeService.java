package com.example.ormlearn.service;

import com.example.ormlearn.entity.Employee;
import com.example.ormlearn.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

   
    public List<Employee> getAllPermanentEmployees() {
        return employeeRepository.getAllPermanentEmployees();
    }

   
    public Double getAverageSalary(int deptId) {
        return employeeRepository.getAverageSalary(deptId);
    }

  
    public List<Employee> getAllEmployeesNative() {
        return employeeRepository.getAllEmployeesNative();
    }

   
    public List<Employee> getByDepartment(int deptId) {
        return employeeRepository.findByDepartmentId(deptId);
    }
}