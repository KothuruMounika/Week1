package com.example.ormlearn.repository;

import com.example.ormlearn.entity.AttemptQuestion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AttemptQuestionRepository extends JpaRepository<AttemptQuestion, Integer> {
}