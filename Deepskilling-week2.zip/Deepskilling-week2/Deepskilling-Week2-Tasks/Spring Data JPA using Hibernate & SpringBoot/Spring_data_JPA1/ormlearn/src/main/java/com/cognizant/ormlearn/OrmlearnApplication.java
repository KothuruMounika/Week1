package com.cognizant.ormlearn;

import com.cognizant.ormlearn.model.Country;
import com.cognizant.ormlearn.service.CountryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import java.util.List;

@SpringBootApplication
public class OrmlearnApplication {

    private static final Logger LOGGER =
            LoggerFactory.getLogger(OrmlearnApplication.class);

    private static CountryService countryService;

    public static void main(String[] args) throws Exception {

        ApplicationContext context =
                SpringApplication.run(
                        OrmlearnApplication.class,
                        args);

        countryService =
                context.getBean(CountryService.class);

        testGetAllCountries();

        testFindCountry();

        testAddCountry();

        testUpdateCountry();

        testDeleteCountry();

        testSearchCountry();

        LOGGER.info("Inside Main");
    }

    private static void testGetAllCountries() {

        LOGGER.info("Start");

        List<Country> countries =
                countryService.getAllCountries();

        LOGGER.debug("Countries : {}", countries);

        LOGGER.info("End");
    }

    private static void testFindCountry()
            throws Exception {

        LOGGER.info("Start");

        Country country =
                countryService.findCountryByCode("IN");

        LOGGER.debug("Country : {}", country);

        LOGGER.info("End");
    }

    private static void testAddCountry()
            throws Exception {

        LOGGER.info("Start");

        Country country =
                new Country("TS", "Telangana");

        countryService.addCountry(country);

        Country result =
                countryService.findCountryByCode("TS");

        LOGGER.debug("Added Country : {}", result);

        LOGGER.info("End");
    }

    private static void testUpdateCountry()
            throws Exception {

        LOGGER.info("Start");

        countryService.updateCountry(
                "TS",
                "Telangana State");

        Country country =
                countryService.findCountryByCode("TS");

        LOGGER.debug("Updated Country : {}", country);

        LOGGER.info("End");
    }

    private static void testDeleteCountry() {

        LOGGER.info("Start");

        countryService.deleteCountry("TS");

        LOGGER.debug("Country Deleted");

        LOGGER.info("End");
    }

    private static void testSearchCountry() {

        LOGGER.info("Start");

        List<Country> countries =
                countryService.searchCountry("Uni");

        LOGGER.debug("Search Result : {}", countries);

        LOGGER.info("End");
    }
}