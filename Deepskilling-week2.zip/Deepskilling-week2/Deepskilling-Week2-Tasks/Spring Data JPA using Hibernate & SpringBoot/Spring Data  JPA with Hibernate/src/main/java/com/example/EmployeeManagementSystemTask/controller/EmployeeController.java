package com.example.employeemanagementsystem.controller;

import com.example.employeemanagementsystem.entity.Employee;
import com.example.employeemanagementsystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository repository;

    @GetMapping
    public List<Employee> getAllEmployees() {
        return repository.findAll();
    }

    @GetMapping("/{id}")
    public Employee getEmployee(@PathVariable Long id) {
        return repository.findById(id).orElse(null);
    }

    @PostMapping
    public Employee saveEmployee(@RequestBody Employee employee) {
        return repository.save(employee);
    }

    @PutMapping("/{id}")
    public Employee updateEmployee(
            @PathVariable Long id,
            @RequestBody Employee employee) {

        employee.setId(id);
        return repository.save(employee);
    }

    @DeleteMapping("/{id}")
    public String deleteEmployee(@PathVariable Long id) {

        repository.deleteById(id);

        return "Employee Deleted Successfully";
    }

    @GetMapping("/search")
    public List<Employee> searchByName(
            @RequestParam String name) {

        return repository.findByName(name);
    }

    @GetMapping("/pagination")
    public Page<Employee> pagination(
            @RequestParam int page,
            @RequestParam int size) {

        Pageable pageable =
                PageRequest.of(page, size);

        return repository.findAll(pageable);
    }

    @GetMapping("/sorting")
    public List<Employee> sorting() {

        return repository.findAll(
                Sort.by("name").ascending()
        );
    }

    @GetMapping("/page-sort")
    public Page<Employee> pageSort(
            @RequestParam int page,
            @RequestParam int size) {

        Pageable pageable =
                PageRequest.of(
                        page,
                        size,
                        Sort.by("name")
                );

        return repository.findAll(pageable);
    }
}