package com.cognizant.ormlearn;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cognizant.ormlearn.model.Department;
import com.cognizant.ormlearn.model.Employee;
import com.cognizant.ormlearn.model.Skill;
import com.cognizant.ormlearn.repository.CountryRepository;
import com.cognizant.ormlearn.repository.StockRepository;
import com.cognizant.ormlearn.service.DepartmentService;
import com.cognizant.ormlearn.service.EmployeeService;
import com.cognizant.ormlearn.service.SkillService;

@SpringBootApplication
public class OrmLearnApplication implements CommandLineRunner {

    @Autowired
    private CountryRepository countryRepository;

    @Autowired
    private StockRepository stockRepository;

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private SkillService skillService;

    public static void main(String[] args) {
        SpringApplication.run(OrmLearnApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {


        testCountryQueries();


        testStockQueries();


        testGetEmployee();
        testAddEmployee();
        testUpdateEmployee();


        testGetDepartment();


        testAddSkillToEmployee();
    }



    private void testCountryQueries() {

        System.out.println("Countries containing 'ou'");

        countryRepository
                .findByNameContainingIgnoreCaseOrderByNameAsc("ou")
                .forEach(System.out::println);

        System.out.println("Countries starting with Z");

        countryRepository
                .findByNameStartingWith("Z")
                .forEach(System.out::println);
    }


    private void testStockQueries() throws Exception {

        SimpleDateFormat sdf =
                new SimpleDateFormat("yyyy-MM-dd");

        Date startDate =
                sdf.parse("2019-09-01");

        Date endDate =
                sdf.parse("2019-09-30");

        System.out.println("Facebook Stocks in September 2019");

        stockRepository
                .findByCodeAndDateBetween(
                        "FB",
                        startDate,
                        endDate)
                .forEach(System.out::println);

        System.out.println("Google Stocks Closing Price > 1250");

        stockRepository
                .findByCodeAndCloseGreaterThan(
                        "GOOGL",
                        1250)
                .forEach(System.out::println);

        System.out.println("Top 3 Highest Volume Stocks");

        stockRepository
                .findTop3ByOrderByVolumeDesc()
                .forEach(System.out::println);

        System.out.println("Lowest 3 Netflix Stocks");

        stockRepository
                .findTop3ByCodeOrderByCloseAsc("NFLX")
                .forEach(System.out::println);
    }



    private void testGetEmployee() {

        Employee employee =
                employeeService.get(1);

        System.out.println(employee);

        System.out.println(employee.getDepartment());

        System.out.println(employee.getSkillList());
    }

    private void testAddEmployee() {

        Employee employee = new Employee();

        employee.setName("John");

        employee.setSalary(60000);

        employee.setPermanent(true);

        Department department =
                departmentService.get(1);

        employee.setDepartment(department);

        employeeService.save(employee);

        System.out.println("Employee Added Successfully");
    }

    private void testUpdateEmployee() {

        Employee employee =
                employeeService.get(1);

        Department department =
                departmentService.get(2);

        employee.setDepartment(department);

        employeeService.save(employee);

        System.out.println("Employee Updated Successfully");
    }


    private void testGetDepartment() {

        Department department =
                departmentService.get(1);

        System.out.println(department);

        System.out.println(
                department.getEmployeeList());
    }

    private void testAddSkillToEmployee() {

        Employee employee =
                employeeService.get(1);

        Skill skill =
                skillService.get(3);

        employee.getSkillList().add(skill);

        employeeService.save(employee);

        System.out.println("Skill Added Successfully");
    }
}