DROP DATABASE IF EXISTS orm_learn;
CREATE DATABASE orm_learn;
USE orm_learn;
CREATE TABLE country (
    co_code VARCHAR(2) PRIMARY KEY,
    co_name VARCHAR(50)
);

CREATE TABLE department (
    dp_id INT PRIMARY KEY,
    dp_name VARCHAR(50)
);
CREATE TABLE skill (
    sk_id INT PRIMARY KEY,
    sk_name VARCHAR(50)
);
CREATE TABLE employee (
    em_id INT PRIMARY KEY,
    em_name VARCHAR(50),
    em_salary DOUBLE,
    em_permanent BOOLEAN,
    em_date_of_birth DATE,
    em_dp_id INT,
    FOREIGN KEY (em_dp_id) REFERENCES department(dp_id)
);
CREATE TABLE employee_skill (
    es_em_id INT,
    es_sk_id INT,
    PRIMARY KEY (es_em_id, es_sk_id),
    FOREIGN KEY (es_em_id) REFERENCES employee(em_id),
    FOREIGN KEY (es_sk_id) REFERENCES skill(sk_id)
);
CREATE TABLE stock (
    st_id INT PRIMARY KEY,
    st_code VARCHAR(10),
    st_date DATE,
    st_open DOUBLE,
    st_close DOUBLE,
    st_volume BIGINT
);
INSERT INTO country VALUES ('CA', 'Canada');
INSERT INTO country VALUES ('DE', 'Germany');
INSERT INTO country VALUES ('FR', 'France');
INSERT INTO country VALUES ('BR', 'Brazil');
INSERT INTO country VALUES ('SG', 'Singapore');
INSERT INTO country VALUES ('KR', 'South Korea');
INSERT INTO country VALUES ('NZ', 'New Zealand');

INSERT INTO department VALUES (1, 'Engineering');
INSERT INTO department VALUES (2, 'Quality Assurance');

INSERT INTO skill VALUES (1, 'Java');
INSERT INTO skill VALUES (2, 'Spring Framework');
INSERT INTO skill VALUES (3, 'MySQL');
INSERT INTO skill VALUES (4, 'JavaScript');
INSERT INTO skill VALUES (5, 'React');

INSERT INTO employee VALUES
(101, 'Rahul', 65000, TRUE, '1998-02-15', 1);

INSERT INTO employee VALUES
(102, 'Priya', 72000, TRUE, '1999-06-10', 1);

INSERT INTO employee VALUES
(103, 'Arjun', 58000, FALSE, '2000-01-25', 2);

INSERT INTO employee VALUES
(104, 'Sneha', 80000, TRUE, '1997-08-18', 1);

INSERT INTO employee VALUES
(105, 'Kiran', 61000, TRUE, '1998-11-30', 2);

INSERT INTO employee VALUES
(106, 'Divya', 75000, TRUE, '1999-04-12', 2);

INSERT INTO employee_skill VALUES (101,1);
INSERT INTO employee_skill VALUES (101,2);

INSERT INTO employee_skill VALUES (102,2);
INSERT INTO employee_skill VALUES (102,5);

INSERT INTO employee_skill VALUES (103,3);
INSERT INTO employee_skill VALUES (103,4);

INSERT INTO employee_skill VALUES (104,1);
INSERT INTO employee_skill VALUES (104,5);

INSERT INTO employee_skill VALUES (105,2);
INSERT INTO employee_skill VALUES (105,3);

INSERT INTO employee_skill VALUES (106,4);
INSERT INTO employee_skill VALUES (106,5);

INSERT INTO stock VALUES
(1, 'AAPL', '2024-01-10', 185.50, 188.20, 15000000);

INSERT INTO stock VALUES
(2, 'AAPL', '2024-01-11', 188.20, 190.10, 14200000);

INSERT INTO stock VALUES
(3, 'AAPL', '2024-01-12', 190.10, 189.75, 13850000);

INSERT INTO stock VALUES
(4, 'MSFT', '2024-02-05', 375.20, 380.45, 9200000);

INSERT INTO stock VALUES
(5, 'MSFT', '2024-02-06', 380.45, 382.80, 8700000);

INSERT INTO stock VALUES
(6, 'MSFT', '2024-02-07', 382.80, 381.50, 9100000);

INSERT INTO stock VALUES
(7, 'TSLA', '2024-03-15', 240.30, 245.60, 18000000);

INSERT INTO stock VALUES
(8, 'TSLA', '2024-03-16', 245.60, 242.90, 17500000);

INSERT INTO stock VALUES
(9, 'TSLA', '2024-03-17', 242.90, 248.10, 19200000);

SELECT * FROM country;
SELECT * FROM department;
SELECT * FROM skill;
SELECT * FROM employee;
SELECT * FROM employee_skill;
SELECT * FROM stock;