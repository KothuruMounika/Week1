public class StrategyTest {

    public static void main(String[] args) {

        PaymentContext context =
                new PaymentContext();

        context.setPaymentStrategy(
                new CreditCardPayment());

        context.executePayment(5000);

        context.setPaymentStrategy(
                new PayPalPayment());

        context.executePayment(3000);
    }
}