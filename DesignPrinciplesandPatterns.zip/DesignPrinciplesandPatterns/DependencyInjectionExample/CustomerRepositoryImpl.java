public class CustomerRepositoryImpl
        implements CustomerRepository {

    @Override
    public String findCustomerById(int id) {

        if (id == 101) {
            return "Kothuru Mounika";
        }

        return "Customer Not Found";
    }
}