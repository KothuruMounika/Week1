package FactoryMethodPatternExample;
public class FactoryTest {

    public static void main(String[] args) {

        // Creating Word Document
        DocumentFactory wordFactory =
                new WordFactory();

        Document word =
                wordFactory.createDocument();

        word.open();

        System.out.println();

        // Creating PDF Document
        DocumentFactory pdfFactory =
                new PdfFactory();

        Document pdf =
                pdfFactory.createDocument();

        pdf.open();

        System.out.println();

        // Creating Excel Document
        DocumentFactory excelFactory =
                new ExcelFactory();

        Document excel =
                excelFactory.createDocument();

        excel.open();
    }
}