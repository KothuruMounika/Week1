class Logger {

    // Step 1: Create static object reference
    private static Logger instance;

    // Step 2: Private constructor
    private Logger() {
        System.out.println("Logger Created");
    }

    // Step 3: Global access method
    public static Logger getInstance() {

        if (instance == null) {
            instance = new Logger();
        }

        return instance;
    }

    // Logging method
    public void log(String message) {
        System.out.println("LOG : " + message);
    }
}