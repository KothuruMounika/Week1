

public class BuilderTest {

    public static void main(String[] args) {

        Computer gamingPC = new Computer.Builder()
                .setCpu("Intel Core i7")
                .setRam(16)
                .setStorage(512)
                .setOperatingSystem("Windows 11")
                .build();

        gamingPC.display();

        System.out.println();

        Computer officePC = new Computer.Builder()
                .setCpu("Intel Core i5")
                .setRam(8)
                .setStorage(256)
                .setOperatingSystem("Windows 10")
                .build();

        officePC.display();
    }
}