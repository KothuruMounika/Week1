package com.example.authorizationresourceserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecureController {

    @GetMapping("/")
    public String home() {
        return "Authorization Resource Server is Running";
    }

    @GetMapping("/secure")
    public String secure() {
        return "This is a Secure Endpoint";
    }
}