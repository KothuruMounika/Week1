package com.example.authorizationresourceserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthorizationResourceServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
