package com.example.jwtsecurity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SecureController {

    @GetMapping("/")
    public String home() {
        return "JWT Security Application is Running";
    }

    @GetMapping("/secure")
    public String secure() {
        return "Welcome! This is a JWT Protected Endpoint.";
    }

}