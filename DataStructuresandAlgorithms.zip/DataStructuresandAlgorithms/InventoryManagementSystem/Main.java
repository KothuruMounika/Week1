public class Main {

    public static void main(String[] args) {

        Inventory inventory = new Inventory();

        Product p1 =
                new Product(101,
                        "Laptop",
                        10,
                        55000);

        Product p2 =
                new Product(102,
                        "Mouse",
                        50,
                        500);

        inventory.addProduct(p1);
        inventory.addProduct(p2);

        inventory.displayProducts();

        inventory.updateProduct(101,
                15,
                54000);

        inventory.displayProducts();

        inventory.deleteProduct(102);

        inventory.displayProducts();
    }
}