public class Main {

    public static void main(String[] args) {

        Book[] books = {

                new Book(
                        101,
                        "C Programming",
                        "Dennis Ritchie"),

                new Book(
                        102,
                        "Data Structures",
                        "Seymour Lipschutz"),

                new Book(
                        103,
                        "Java Programming",
                        "Herbert Schildt")
        };

        int index =
                SearchBook.linearSearch(
                        books,
                        "Java Programming");

        if (index != -1) {
            System.out.println(
                    "Book Found at Index : "
                            + index);
        } else {
            System.out.println(
                    "Book Not Found");
        }
    }
}