public class Main {

    public static void main(String[] args) {

        double amount = 10000;
        double growthRate = 0.10;
        int years = 5;

        double value =
                FinancialForecast.futureValue(
                        amount,
                        growthRate,
                        years);

        System.out.println(
                "Future Value After "
                        + years
                        + " Years : "
                        + value);
    }
}