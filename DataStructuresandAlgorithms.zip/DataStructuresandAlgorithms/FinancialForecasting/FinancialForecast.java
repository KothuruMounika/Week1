public class FinancialForecast {

    public static double futureValue(
            double amount,
            double growthRate,
            int years) {

        if (years == 0) {
            return amount;
        }

        return (1 + growthRate)
                * futureValue(
                        amount,
                        growthRate,
                        years - 1);
    }
}