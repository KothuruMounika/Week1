public class Main {

    public static void main(String[] args) {

        Product[] products = {
                new Product(101,
                        "Camera",
                        "Electronics"),

                new Product(102,
                        "Laptop",
                        "Electronics"),

                new Product(103,
                        "Mobile",
                        "Electronics"),

                new Product(104,
                        "Watch",
                        "Accessories")
        };

        int index =
                SearchOperations
                        .linearSearch(products,
                                "Mobile");

        System.out.println(
                "Linear Search Index : "
                        + index);

        index =
                SearchOperations
                        .binarySearch(products,
                                "Mobile");

        System.out.println(
                "Binary Search Index : "
                        + index);
    }
}