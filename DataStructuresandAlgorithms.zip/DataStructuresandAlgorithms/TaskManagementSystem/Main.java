public class Main {

    public static void main(String[] args) {

        TaskList list = new TaskList();

        list.addTask(
                1,
                "Prepare Report",
                "Pending");

        list.addTask(
                2,
                "Submit Assignment",
                "Completed");

        list.traverseTasks();

        list.searchTask(1);

        list.deleteTask(2);

        list.traverseTasks();
    }
}