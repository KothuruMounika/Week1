public class TaskList {

    Task head;

    public void addTask(int id,
                        String name,
                        String status) {

        Task newTask =
                new Task(id, name, status);

        newTask.next = head;
        head = newTask;

        System.out.println("Task Added");
    }

    public void searchTask(int id) {

        Task current = head;

        while (current != null) {

            if (current.taskId == id) {

                System.out.println("Task Found");
                System.out.println("Task ID : "
                        + current.taskId);

                System.out.println("Task Name : "
                        + current.taskName);

                System.out.println("Status : "
                        + current.status);

                return;
            }

            current = current.next;
        }

        System.out.println("Task Not Found");
    }

    public void traverseTasks() {

        System.out.println("\nTask Details");

        Task current = head;

        while (current != null) {

            System.out.println(
                    current.taskId + " "
                            + current.taskName
                            + " "
                            + current.status);

            current = current.next;
        }
    }

    public void deleteTask(int id) {

        if (head == null) {
            return;
        }

        if (head.taskId == id) {
            head = head.next;
            System.out.println("Task Deleted");
            return;
        }

        Task current = head;

        while (current.next != null) {

            if (current.next.taskId == id) {
                current.next =
                        current.next.next;

                System.out.println("Task Deleted");
                return;
            }

            current = current.next;
        }

        System.out.println("Task Not Found");
    }
}