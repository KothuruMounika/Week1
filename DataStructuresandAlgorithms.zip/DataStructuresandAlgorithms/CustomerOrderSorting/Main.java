public class Main {

    public static void main(String[] args) {

        Order[] orders = {
                new Order(1,
                        "Mounika",
                        2500),

                new Order(2,
                        "Rahul",
                        8000),

                new Order(3,
                        "Priya",
                        4000)
        };

        SortOperations.quickSort(
                orders,
                0,
                orders.length - 1);

        System.out.println(
                "Sorted Orders");

        for (Order o : orders) {
            o.display();
        }
    }
}