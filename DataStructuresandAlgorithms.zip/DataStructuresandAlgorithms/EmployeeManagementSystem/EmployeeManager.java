public class EmployeeManager {

    Employee[] employees = new Employee[100];
    int size = 0;

    public void addEmployee(Employee e) {

        if (size < employees.length) {
            employees[size] = e;
            size++;
            System.out.println("Employee Added");
        }
    }

    public void searchEmployee(int id) {

        for (int i = 0; i < size; i++) {

            if (employees[i].employeeId == id) {
                System.out.println("Employee Found");
                employees[i].display();
                return;
            }
        }

        System.out.println("Employee Not Found");
    }

    public void traverseEmployees() {

        System.out.println("\nEmployee Details");

        for (int i = 0; i < size; i++) {
            employees[i].display();
        }
    }

    public void deleteEmployee(int id) {

        for (int i = 0; i < size; i++) {

            if (employees[i].employeeId == id) {

                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }

                employees[size - 1] = null;
                size--;

                System.out.println("Employee Deleted");
                return;
            }
        }

        System.out.println("Employee Not Found");
    }
}