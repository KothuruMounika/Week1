public class Main {

    public static void main(String[] args) {

        EmployeeManager manager =
                new EmployeeManager();

        manager.addEmployee(
                new Employee(101,
                        "Mounika",
                        "Developer",
                        50000));

        manager.addEmployee(
                new Employee(102,
                        "Rahul",
                        "Tester",
                        45000));

        manager.traverseEmployees();

        manager.searchEmployee(101);

        manager.deleteEmployee(102);

        manager.traverseEmployees();
    }
}